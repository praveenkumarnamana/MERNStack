package com.praveen.MERN;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MernApplicationTests {

	@Test
	void contextLoads() {
	}

}
